package phase1;
import java.util.*;
public class LongestIncreasingSubsequence {
	static int lis(int arr[], int n)
    {
        int lis[] = new int[n];
        int i, j, max = 0;
        for (i = 0; i < n; i++)
            lis[i] = 1;
        for (i = 1; i < n; i++)
            for (j = 0; j < i; j++)
                if (arr[i] > arr[j] && lis[i] < lis[j] + 1)
                    lis[i] = lis[j] + 1;
        for (i = 0; i < n; i++)
            if (max < lis[i])
                max = lis[i];
 
        return max;
    }
	public static void main(String[] args)
	{
Scanner sc = new Scanner(System.in);
		        System.out.println("Enter a size of the array :");
				int n = sc.nextInt();
				System.out.println("Enter array Element :");
				int[] a = new int[n];

				for (int i = 0; i < n; i++) {
					a[i] = sc.nextInt();
				}

				sc.close();

				System.out.println("Total Length of LIS:"+lis(a,n));
					
			}

	

}